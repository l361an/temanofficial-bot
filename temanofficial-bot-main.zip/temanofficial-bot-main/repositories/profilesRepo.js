// repositories/profilesRepo.js

// ======================================================
// Basic getters / actions
// ======================================================

export async function findTelegramIdByNickname(env, nickname) {
  const clean = String(nickname || "").trim();
  if (!clean) return null;

  const { results } = await env.DB.prepare(
    `SELECT telegram_id FROM profiles WHERE nickname = ? LIMIT 1`
  )
    .bind(clean)
    .all();

  return results?.[0]?.telegram_id ?? null;
}

export async function deleteProfileByTelegramId(env, telegramId) {
  await env.DB.prepare(`DELETE FROM profiles WHERE telegram_id = ?`)
    .bind(String(telegramId))
    .run();
}

export async function listProfilesByStatus(env, status) {
  const clean = String(status || "").trim();
  if (!clean) return [];

  // ✅ Konsisten include username + nickname
  const { results } = await env.DB.prepare(`
    SELECT telegram_id, nama_lengkap, username, nickname
    FROM profiles
    WHERE status = ?
    ORDER BY diupdate_pada DESC, dibuat_pada DESC, nama_lengkap ASC
  `)
    .bind(clean)
    .all();

  return results ?? [];
}

export async function getProfileStatus(env, telegramId) {
  const { results } = await env.DB.prepare(
    `SELECT status FROM profiles WHERE telegram_id = ? LIMIT 1`
  )
    .bind(String(telegramId))
    .all();

  return results?.[0]?.status ?? null;
}

// ✅ NEW: dipakai untuk guard finalize
export async function getProfileByTelegramId(env, telegramId) {
  const row = await env.DB.prepare(
    `
    SELECT id, telegram_id, status, nama_lengkap, username, nickname
    FROM profiles
    WHERE telegram_id = ?
    LIMIT 1
  `
  )
    .bind(String(telegramId))
    .first();

  return row ?? null;
}

// ✅ NEW: reset data lama untuk kasus rejected (boleh daftar ulang)
export async function resetRejectedProfile(env, telegramId) {
  const tid = String(telegramId);
  const existing = await getProfileByTelegramId(env, tid);

  if (!existing?.telegram_id) return { ok: true, didReset: false };
  if (existing.status !== "rejected")
    return { ok: false, reason: "not_rejected", existing };

  // hapus relasi kategori dulu
  await env.DB.prepare(`DELETE FROM profile_categories WHERE profile_id = ?`)
    .bind(String(existing.id))
    .run();

  // hapus profile-nya
  await env.DB.prepare(`DELETE FROM profiles WHERE telegram_id = ?`)
    .bind(tid)
    .run();

  return { ok: true, didReset: true };
}

export async function approveProfile(env, telegramId, adminId) {
  await env.DB.prepare(`
    UPDATE profiles
    SET status = 'approved',
        verificator_admin_id = ?
    WHERE telegram_id = ?
  `)
    .bind(String(adminId), String(telegramId))
    .run();
}

export async function rejectProfile(env, telegramId) {
  await env.DB.prepare(`
    UPDATE profiles
    SET status = 'rejected'
    WHERE telegram_id = ?
  `)
    .bind(String(telegramId))
    .run();
}

export async function insertPendingProfile(env, payload) {
  await env.DB.prepare(`
    INSERT INTO profiles (
      id,
      telegram_id,
      nama_lengkap,
      nik,
      foto_ktp_file_id,
      nickname,
      username,
      no_whatsapp,
      kecamatan,
      kota,
      foto_closeup_file_id,
      foto_fullbody_file_id,
      status
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
  `)
    .bind(
      payload.id,
      String(payload.telegram_id),
      payload.nama_lengkap,
      payload.nik,
      payload.foto_ktp_file_id,
      payload.nickname,
      payload.username,
      payload.no_whatsapp,
      payload.kecamatan,
      payload.kota,
      payload.foto_closeup_file_id,
      payload.foto_fullbody_file_id
    )
    .run();
}

// ======================================================
// TAMBAHAN BARU (tidak mengubah fungsi lama)
// ======================================================

// Digunakan oleh /suspend dan /activate
export async function setProfileStatus(env, telegramId, status) {
  await env.DB.prepare(`
    UPDATE profiles
    SET status = ?
    WHERE telegram_id = ?
  `)
    .bind(String(status), String(telegramId))
    .run();
}

// Digunakan oleh /ceksub
// Aman walaupun kolom subscription belum ada
export async function getSubscriptionInfo(env, telegramId) {
  try {
    const { results } = await env.DB.prepare(`
      SELECT subscription_status, subscription_end_at
      FROM profiles
      WHERE telegram_id = ?
      LIMIT 1
    `)
      .bind(String(telegramId))
      .all();

    if (!results?.length) return { supported: true, found: false };

    return {
      supported: true,
      found: true,
      subscription_status: results[0]?.subscription_status ?? null,
      subscription_end_at: results[0]?.subscription_end_at ?? null,
    };
  } catch (err) {
    return { supported: false };
  }
}

// ======================================================
// ✅ VIEWPARTNER SUPPORT (baru)
// ======================================================

// ambil profile lengkap by telegram_id (SELECT * biar fleksibel)
export async function getProfileFullByTelegramId(env, telegramId) {
  const row = await env.DB.prepare(`
    SELECT *
    FROM profiles
    WHERE telegram_id = ?
    LIMIT 1
  `)
    .bind(String(telegramId))
    .first();

  return row ?? null;
}

// ambil profile lengkap by nickname
export async function getProfileFullByNickname(env, nickname) {
  const row = await env.DB.prepare(`
    SELECT *
    FROM profiles
    WHERE nickname = ?
    LIMIT 1
  `)
    .bind(String(nickname))
    .first();

  return row ?? null;
}

// list kategori by profile_id (kalau tabel/join belum ada: return [])
export async function listCategoryKodesByProfileId(env, profileId) {
  try {
    const res = await env.DB.prepare(`
      SELECT c.kode AS kode
      FROM profile_categories pc
      JOIN categories c ON c.id = pc.category_id
      WHERE pc.profile_id = ?
      ORDER BY c.kode ASC
    `)
      .bind(String(profileId))
      .all();

    return (res?.results || []).map((r) => r.kode).filter(Boolean);
  } catch (err) {
    return [];
  }
}

// ======================================================
// ✅ SELF UPDATE (ACTIVE USER) - WAJIB ADA EXPORT INI
// ======================================================

function normalizeUsername(u) {
  return String(u ?? "").trim().replace(/^@/, "");
}

/**
 * Username HARUS ikut Telegram (auto sync).
 * Dipanggil dari routes/telegram.js tiap message masuk.
 * Tidak membuat username editable.
 */
export async function syncProfileUsernameFromTelegram(
  env,
  telegramId,
  telegramUsername
) {
  const tid = String(telegramId || "").trim();
  if (!tid) return { ok: false, reason: "empty_tid" };

  const uname = normalizeUsername(telegramUsername); // boleh ""
  const existing = await env.DB.prepare(`
    SELECT username
    FROM profiles
    WHERE telegram_id = ?
    LIMIT 1
  `)
    .bind(tid)
    .first();

  // kalau profile belum ada, skip aja
  if (!existing) return { ok: true, skipped: true, reason: "no_profile" };

  const curr = normalizeUsername(existing.username);
  if (curr === uname) return { ok: true, skipped: true };

  await env.DB.prepare(`
    UPDATE profiles
    SET username = ?, diupdate_pada = datetime('now')
    WHERE telegram_id = ?
  `)
    .bind(uname, tid)
    .run();

  return { ok: true, skipped: false };
}

/**
 * Update field yang BOLEH diedit user ACTIVE:
 * - nickname
 * - no_whatsapp
 * - kecamatan
 * - kota
 * (username TIDAK boleh diedit)
 */
export async function updateEditableProfileFields(env, telegramId, patch) {
  const tid = String(telegramId || "").trim();
  if (!tid) return { ok: false, reason: "empty_tid" };

  const allowed = ["nickname", "no_whatsapp", "kecamatan", "kota"];
  const keys = Object.keys(patch || {}).filter((k) => allowed.includes(k));

  if (!keys.length) return { ok: false, reason: "no_allowed_fields" };

  const sets = keys.map((k) => `${k} = ?`).join(", ");
  const values = keys.map((k) => patch[k]);

  await env.DB.prepare(`
    UPDATE profiles
    SET ${sets}, diupdate_pada = datetime('now')
    WHERE telegram_id = ?
  `)
    .bind(...values, tid)
    .run();

  return { ok: true };
}

/**
 * Update foto yang BOLEH diedit user ACTIVE:
 * - foto_closeup_file_id saja
 */
export async function updateCloseupPhoto(env, telegramId, fotoCloseupFileId) {
  const tid = String(telegramId || "").trim();
  if (!tid) return { ok: false, reason: "empty_tid" };

  const fileId = String(fotoCloseupFileId || "").trim();
  if (!fileId) return { ok: false, reason: "empty_file_id" };

  await env.DB.prepare(`
    UPDATE profiles
    SET foto_closeup_file_id = ?, diupdate_pada = datetime('now')
    WHERE telegram_id = ?
  `)
    .bind(fileId, tid)
    .run();

  return { ok: true };
}

/**
 * Set kategori by KODE (input array kode)
 * - replace semua relasi profile_categories
 */
export async function setProfileCategoriesByCodes(env, telegramId, kodeList) {
  const tid = String(telegramId || "").trim();
  if (!tid) return { ok: false, reason: "empty_tid" };

  const profile = await env.DB.prepare(`
    SELECT id
    FROM profiles
    WHERE telegram_id = ?
    LIMIT 1
  `)
    .bind(tid)
    .first();

  if (!profile?.id) return { ok: false, reason: "no_profile" };

  const codes = Array.isArray(kodeList)
    ? kodeList.map((x) => String(x).trim()).filter(Boolean)
    : [];

  if (!codes.length) return { ok: false, reason: "empty_codes" };

  // resolve kode -> category_id
  const placeholders = codes.map(() => "?").join(",");
  const res = await env.DB.prepare(`
    SELECT id, kode
    FROM categories
    WHERE kode IN (${placeholders})
       OR LOWER(kode) IN (${placeholders})
  `).bind(...codes, ...codes.map((c) => c.toLowerCase())).all();

  const rows = res?.results || [];
  const ids = rows.map((r) => r.id).filter(Boolean);

  if (!ids.length) return { ok: false, reason: "no_match" };

  // replace relations
  await env.DB.prepare(`
    DELETE FROM profile_categories
    WHERE profile_id = ?
  `)
    .bind(String(profile.id))
    .run();

  for (const cid of ids) {
    await env.DB.prepare(`
      INSERT INTO profile_categories (profile_id, category_id)
      VALUES (?, ?)
    `)
      .bind(String(profile.id), String(cid))
      .run();
  }

  await env.DB.prepare(`
    UPDATE profiles
    SET diupdate_pada = datetime('now')
    WHERE id = ?
  `)
    .bind(String(profile.id))
    .run();

  return { ok: true, count: ids.length };
}
