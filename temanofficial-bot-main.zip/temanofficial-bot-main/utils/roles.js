// utils/roles.js

// Role mapping:
// - owner dianggap setara superadmin
// - admin = admin biasa

export function isAdminRole(role) {
  return role === "admin" || role === "superadmin" || role === "owner";
}

export function isSuperadminRole(role) {
  return role === "superadmin" || role === "owner";
}
